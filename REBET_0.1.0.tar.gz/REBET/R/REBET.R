library(SC3)
library(SingleCellExperiment)
library(scater)
library(cluster)
library(infotheo)
library(ggplot2)
library(sva)
library(flexclust)
library("foreach")
library("doParallel")

NMI_cal <- function(mylist1, mylist2) {
  return(2 * (entropy(mylist1) + entropy(mylist2) - entropy(cbind(mylist1, mylist2))) /
    (entropy(mylist1) + entropy(mylist2)))
}

cal_rangeNMI <- function(combat_label, label_pred, Kmax) {
  rangeNMI <- c()
  for (j in 1:(Kmax - 1)) {
    # NMI
    combat_y <- as.data.frame(combat_label[j])
    NMI <- c()
    for (i in 1:(Kmax - 1)) {
      NMI <- c(NMI, list(NMI_cal(
        as.numeric(combat_y[, i]), label_pred[, j]
      )))
    }
    rangeNMI <- c(rangeNMI, (max(as.numeric(NMI)) - min(as.numeric(NMI))))
  }
  list(rangeNMI)
}

RemoveBatchEffects <- function(data, label) {
  modcombat <- model.matrix(~1, data = label)
  combat_data <- ComBat(
    dat = as.matrix(data),
    batch = labelpred,
    mod = modcombat,
    par.prior = FALSE
  )
  return(combat_data)
}

kmeansWrapper <-
  function(data,
           k,
           nstart = 20,
           iter.max = 1000,
           ...) {
    if (nstart > nrow(data)) {
      nstart <- nrow(data)
    }
    kmeans(
      x = data,
      centers = k,
      nstart = nstart,
      iter.max = iter.max,
      ...
    )$cluster
  }

pamWrapper <- function(data, k, ...) {
  pam(data, k, cluster.only = T, ...)
}

hclustWrapper <- function(data, k, ...) {
  cutree(hclust(dist(data), ...), k = k)
}

SC3Wrapper <- function(data, k, ...) {
  require(SC3)
  require(SingleCellExperiment)
  x <- t(data)
  colnames(x) <- paste("sample", seq(1, ncol(x)), sep = "")
  rownames(x) <- paste("gene", seq(1, nrow(x)), sep = "")
  # create a SingleCellExperiment object
  sce <- SingleCellExperiment(assays = list(
    counts = as.matrix(x),
    # logcounts = log2(as.matrix(x) + 1)
    logcounts = as.matrix(x)
  ))
  # define feature names in feature_symbol column
  rowData(sce)$feature_symbol <- rownames(sce)
  # remove features with duplicated names
  sce <- sce[!duplicated(rowData(sce)$feature_symbol), ]
  # define spike-ins
  isSpike(sce, "ERCC") <- grepl("ERCC", rowData(sce)$feature_symbol)
  sce <- sc3(sce,
    ks = k,
    gene_filter = FALSE,
    biology = FALSE
  )
  return(as.numeric(as.data.frame(colData(sce))[, 1]))
}

GetClusteringAlgorithm <-
  function(clusteringMethod = "SC3",
           clusteringFunction = NULL,
           clusteringOptions = NULL,
           ...) {
    name <- clusteringMethod

    if (!is.function(clusteringFunction)) {
      switch(
        clusteringMethod,
        SC3 = {
          clusteringFunction <- SC3Wrapper
        },
        kmeans = {
          clusteringFunction <- kmeansWrapper
        },
        pam = {
          clusteringFunction <- pamWrapper
        },
        hclust = {
          clusteringFunction <- hclustWrapper
        },
        {
          stop("clusteringMethod not found. Please pass a clusteringFunction instead")
        }
      )
    }
    else {
      name <- "Unknown"
    }

    list(
      fun = function(data, k) {
        do.call(clusteringFunction, c(
          list(data = data, k = k), clusteringOptions
        ))
      },
      name = name
    )
  }

GetPartition <-
  function(data,
           clusRange,
           clusteringAlgorithm = clusteringAlgorithm$fun,
           ncore = 2,
           clusteringOptions = NULL) {
    # data <- prcomp(data)$x
    # groupings <- list()
    clusteringOptions <- clusteringOptions

    .ncore <- if (.Platform$OS.type == "unix") {
      ncore
    } else {
      1
    }

    # seeds = abs(round(rnorm(max(clusRange))*10^6))
    parCluster <- makeCluster(ncore)
    clusterEvalQ(parCluster, library(parallel))
    # 添加并行计算中用到的包
    clusterExport(
      parCluster,
      varlist = c("clusteringAlgorithm", "clusteringOptions"),
      envir = environment()
    )
    registerDoParallel(parCluster)

    groupings <- foreach(i = clusRange, .combine = c) %dopar% {
      # set.seed(seeds[i])
      list(group = clusteringAlgorithm(data, i))
    }
    # stopImplicitCluster()
    list(groupings)
  }

GetNoise <- function(data, noisePercent = "median") {
  if (is.null(noisePercent)) {
    noisePercent <- "median"
  }
  if (noisePercent == "median") {
    sds <- apply(data, 2, sd)
    noise <- median(sds)
  } else {
    sds <- apply(data, 2, sd)
    sds <- sort(sds)
    ind <- round(length(sds) * noisePercent / 100)
    noise <- sds[ind]
  }
  noise
}

AddNoisePerturb <- function(data, noise) {
  rowNum <- nrow(data)
  colNum <- ncol(data)
  epsilon <-
    matrix(
      data = rnorm(rowNum * colNum, mean = 0, sd = noise),
      nrow = rowNum,
      ncol = colNum
    )
  data <- data + epsilon
}

RemoveBetweenClassVariance <-
  function(data, label_pred, ncore = 2, Kmax) {
    parCluster <- makeCluster(ncore, type = "FORK")
    registerDoParallel(parCluster)
    clusterEvalQ(parCluster, c(library(sva)))

    batch_effect_removed_data <- foreach(i = 1:(Kmax - 1)) %dopar% {
      labelpred <- as.data.frame(label_pred[, i])
      rownames(labelpred) <- paste("sample", seq(1, nrow(data)), sep = "")
      colnames(labelpred) <- "pred"
      modcombat <- model.matrix(~1, data = labelpred)
      combat_data <- ComBat(
        dat = as.matrix(t(data)),
        batch = labelpred$pred,
        mod = modcombat,
        par.prior = FALSE
      )
      combat_data <- matrix(combat_data,
        nrow = nrow(combat_data),
        ncol = ncol(combat_data)
      )
    }
  }

GetOptimalCluster <- function(rangeNMI) {
  rangeNMI <- as.data.frame(rangeNMI)
  m <- apply(rangeNMI, 1, mean)
  return(which.min(m) + 1)
}

#' Find Optimal number of clusters By REBET.
#'
#' REmoval of Batch Effect and Testing (REBET), a method for determining the
#' number of cell clusters. In this method, cells are first partitioned into k
#' clusters. Second, the batch effects among these k clusters are then removed.
#' Third, the quality of batch effect removal is evaluated with a metric,
#' namely, the average range of normalized mutual information (ARNMI),
#' which measures how uniformly the cells with batch-effects-removal are mixed.
#' By testing a range of k values, the k value that corresponds to the lowest
#' ARNMI is determined to be the optimal number of clusters.
#' @import SC3
#' SingleCellExperiment
#' scater
#' cluster
#' infotheo
#' sva
#' flexclust
#' foreach
#' doParallel
#' @param data Input matrix or data frame.
#' The rows represent items while the columns represent features.
#' @param Kmax The maximum number of clusters.
#' The algorithm runs from \code{k = 2} to \code{k = kMax}. Default value is
#' \code{10}.
#' @param ncore Number of cores that the algorithm should use. Default value is
#' \code{2}.
#' @param clusteringMethod The name of built-in clustering algorithm that
#' clustering will use.
#' Currently supported algorithm are \code{SC3}, \code{kmeans}, \code{pam}
#' and \code{hclust}. Default value is "\code{SC3}".
#' @param clusteringOptions A list of parameter will be passed to the clustering
#'  algorithm in \code{clusteringMethod}.
#' @param clusteringFunction The clustering algorithm function that will be used
#'  instead of built-in algorithms.
#' @param perturbMethod The name of built-in perturbation method that
#' PerturbationClustering will use,
#' currently supported methods are \code{noise} and \code{subsampling}.
#' Default value is "\code{noise}".
#' @param perturbOptions A list of parameter will be passed to the perturbation
#' method in \code{perturbMethod}.
#' @param perturbFunction The perturbation method function that will be used
#' instead of built-in ones.
#' @param perturbNum Number of times the batch_effects_removed data will be
#' disturbed. Default value is \code{20}.
#' @return \item{optimalK}{The optimal number of clusters.}
#' @export
#' @examples
#' data(Ramskold)
#' REBET(data = data, Kmax = 2)

REBET <- function(data,
                  Kmax = 10,
                  perturbNum = 20,
                  ncore = 2,
                  clusteringMethod = "SC3",
                  seed = 123,
                  clusteringFunction = NULL,
                  clusteringOptions = NULL) {
  set.seed(seed)
  rownames(data) <- paste("sample", seq(1, nrow(data)), sep = "")
  colnames(data) <- paste("gene", seq(1, ncol(data)), sep = "")
  clusteringAlgorithm <- GetClusteringAlgorithm(
    clusteringMethod = clusteringMethod,
    clusteringFunction = clusteringFunction,
    clusteringOptions = clusteringOptions
  )
  clusteringOptions <- clusteringOptions
  # get initial partition
  initial_group <- GetPartition(
    data = data,
    clusRange = 2:Kmax,
    clusteringAlgorithm = clusteringAlgorithm$fun,
    ncore = ncore,
    clusteringOptions = clusteringOptions
  )
  label_pred <- as.data.frame(initial_group)
  # remove batch effects
  batch_effect_removed_data <- RemoveBetweenClassVariance(
    data = data,
    label_pred = label_pred,
    ncore = ncore,
    Kmax = Kmax
  )

  # find Optimal Cluster
  rangeNMI <- c()
  ARI <- c()
  for (k in 1:perturbNum) {
    combat_label <- c()
    for (i in 1:(Kmax - 1)) {
      x <- as.data.frame(batch_effect_removed_data[i])
      # get perturbated data
      x_noise <- AddNoisePerturb(data = x, noise = GetNoise(x))
      label <- GetPartition(x_noise, 2:Kmax, clusteringAlgorithm$fun)
      combat_label <- c(combat_label, list(label))
    }
    result <- cal_rangeNMI(combat_label, label_pred, Kmax = Kmax)
    rangeNMI <- c(rangeNMI, result[1])
  }

  return(list(optimalK = GetOptimalCluster(rangeNMI)))
}
